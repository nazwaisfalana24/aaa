<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-md-10">
        <form action="/perjalanan/update/<?php echo e($perjalanan->id); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('PUT')); ?>


          <div class="card">
            <div class="card-header pb-0">
              <div class="d-flex align-items-center">
                <p class="mb-0">Perjalanan</p>
                <button class="btn btn-primary btn-sm ms-auto">Save</button>
              </div>
            </div>
            <div class="card-body">
              <p class="text-uppercase text-sm">Data Perjalanan</p>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="example-text-input" class="form-control-label">Tanggal</label>
                    <input class="form-control" type="date" name="tanggal" value="<?php echo e($perjalanan->tanggal); ?>">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="example-text-input" class="form-control-label">Jam</label>
                    <input class="form-control" type="time" name="jam" value="<?php echo e($perjalanan->jam); ?>"> 
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="example-text-input" class="form-control-label">Lokasi</label>
                    <input class="form-control" type="text" name="lokasi" value="<?php echo e($perjalanan->lokasi); ?>">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="example-text-input" class="form-control-label">Suhu Tubuh</label>
                    <input class="form-control" type="number" name="suhu_tubuh" value="<?php echo e($perjalanan->suhu_tubuh); ?>">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="example-text-input" class="form-control-label">Id User</label>
                    <select class="form-control"  name="id_user" id="id_user" value="<?php echo e($perjalanan->id_user); ?>">
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($i->id); ?>"><?php echo e($i->id); ?>. <?php echo e($i->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
              </div>
            </div>
        </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<!-- 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <center>
        <h1>Perjalanan </h1>
    <form action="/perjalanan/update/<?php echo e($perjalanan->id); ?>" method="post">
        <?php echo csrf_field(); ?> 
        <?php echo method_field('PUT'); ?>
        <table>
            <tr>
                <td>Tanggal</td>
                <td> : <input type="date"  name="tanggal" value="<?php echo e($perjalanan->tanggal); ?>"></td>
            </tr>
            <tr>
                <td>Jam</td>
                <td> : <input type="time" name="jam" value="<?php echo e($perjalanan->jam); ?>"></td>
            </tr>
            <tr>
                <td>Lokasi</td>
                <td> : <input type="text" name="lokasi" value="<?php echo e($perjalanan->lokasi); ?>"></td>
            </tr>
            <tr>
                <td>Suhu Tubuh</td>
                <td> : <input type="text" name="suhu_tubuh" value="<?php echo e($perjalanan->suhu_tubuh); ?>"></td>
            </tr>
            <tr>
                <td>Id User</td>
                <td> : <input type="number" name="id_user" value="<?php echo e($perjalanan->id_user); ?>"></td>
            </tr>
        </table>
        <button type="submit">Save</button>
    </form>
</body>
</html> -->
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app_perjalanan\resources\views/perjalanan/edit.blade.php ENDPATH**/ ?>