<?php $__env->startSection('content'); ?>
<H1>tes</H1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app_perjalanan\resources\views/profiles.blade.php ENDPATH**/ ?>