<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
          <div class="card mb-4">
            <div class="card-header pb-0">
              <h6>Peduli Diri</h6>
              <a class="btn btn-success btn-sm ms-auto" href="/perjalanan/create"> Tambah Data </a>
            </div>
            <div class="card-body px-0 pt-0 pb-2">
              <div class="table-responsive p-0">
                <table class="table align-items-center mb-0">
                  <thead>
                    <tr>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">No.</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Tanggal</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Jam</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Lokasi</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Suhu Tubuh</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Id User</th>
                      <th class="text-center text-secondary opacity-7"></th>
                    </tr>
                  </thead>
                  <?php $__currentLoopData = $perjalanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                  <tbody>
                    <tr>
                        <td class="align-middle text-center text-sm"><?php echo e($i+1); ?></td>
                        <td class="align-middle text-center text-sm"><?php echo e($a->tanggal); ?></td>
                        <td class="align-middle text-center text-sm"><?php echo e($a->jam); ?></td>
                        <td class="align-middle text-center text-sm"><?php echo e($a->lokasi); ?></td}>
                        <td class="align-middle text-center text-sm"><?php echo e($a->suhu_tubuh); ?></td}>
                        <td class="align-middle text-center text-sm"><?php echo e($a->id_user); ?></td}>
                        <td>
                        <a class="btn btn-link text-dark px-3 mb-0" href="/perjalanan/edit/<?php echo e($a->id); ?>"><i class="fas fa-pencil-alt text-dark me-2" aria-hidden="true"></i>Edit</a>    
                        </td}>
                      </tr>
                  </tbody>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
              </div>
            </div>
          </div>
        </div>
    </div>
</div>


<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Data Perjalanan</title>
</head>
<body>
    <center>
        <h1> Tambah Data </h1>
    <table border="2">
        <thead>
             <tr>
                 <th>No</th>
                 <th>Tanggal</th>
                 <th>Jam</th>
                 <th>Lokasi</th>
                 <th>Suhu Tubuh</th>
                 <th>Id User</th>
                 <th> Aksi </th>
             </tr>
        </thead>
        <?php $__currentLoopData = $perjalanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u => $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
                <tr>
                    <th><?php echo e($u+1); ?></th>
                    <th><?php echo e($i->tanggal); ?></th>
                    <th><?php echo e($i->jam); ?></th>
                    <th><?php echo e($i->lokasi); ?></th>
                    <th><?php echo e($i->suhu_tubuh); ?></th>
                    <th><?php echo e($i->id_user); ?></th>
                    <th><a href="/perjalanan/edit/<?php echo e($i->id); ?>" class="btn btn-success"> Edit </a>
                        <a href="/perjalanan/destroy/<?php echo e($i->id); ?>" class="btn btn-danger"> Hapus </a>
                        <a href="/perjalanan/show/<?php echo e($i->id); ?>" class="btn btn-warning"> Show </a>
                </th>
            </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <a href="/perjalanan/create"> Tambah Data </a>
</body>
</html> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app_perjalanan\resources\views/perjalanan/index.blade.php ENDPATH**/ ?>