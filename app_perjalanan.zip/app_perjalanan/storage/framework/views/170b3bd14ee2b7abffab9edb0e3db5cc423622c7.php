<!DOCTYPE html>
<html>
<head>
	<title>PRINT USER</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>

	<div class="container">
		<center>
			<h4>PRINT USER</h4>
			<h5><a target="_blank" href="https://www.malasngoding.com/membuat-laporan-…n-dompdf-laravel/">www.malasngoding.com</a></h5>
		</center>
		<br/>
		<a href="/pegawai/cetak_pdf" class="btn btn-primary" target="_blank">CETAK PDF</a>
		<table class='table table-bordered'>
        <thead>
                    <tr>
                      <th> No.</th>
                      <th>NIK</th>
                      <th>Nama</th>
                      <th>No Telp</th>
                      <th>Email</th>
                      <th>Username</th>
                      <th>Aksi</th>
                      
                    </tr>
                  </thead>
                  <?php $__currentLoopData = $userr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                  <tbody>
                    <tr>
                        <td><?php echo e($i+1); ?></td>
                        <td><?php echo e($a->nik); ?></td>
                        <td><?php echo e($a->nama); ?></td>
                        <td><?php echo e($a->telp); ?></td}>
                        <td><?php echo e($a->email); ?></td>
                        <td><?php echo e($a->username); ?></td}>
                     
                        
                      </tr>
                  </tbody>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>				
			</tbody>
		</table>

	</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\app_perjalanan\resources\views/userr/print.blade.php ENDPATH**/ ?>