<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
          <div class="card mb-4">
            <div class="card-header pb-0">
              <h6>Peduli Diri</h6>
              <a href="/userr/cetak_pdf" target="_blank">
                <button type="button" class="btn btn-success">
                Cetak
                </button>
              </a>
            </div>
            <div class="card-body px-0 pt-0 pb-2">
              <div class="table-responsive p-0">
                <table class="table align-items-center mb-0">
                  <thead>
                    <tr>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">No.</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">NIK</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Nama</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">No Telp</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Email</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Username</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Aksi</th>
                      <th class="text-center text-secondary opacity-7"></th>
                    </tr>
                  </thead>
                  <?php $__currentLoopData = $userr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                  <tbody>
                    <tr>
                        <td class="align-middle text-center text-sm"><?php echo e($i+1); ?></td>
                        <td class="align-middle text-center text-sm"><?php echo e($a->nik); ?></td>
                        <td class="align-middle text-center text-sm"><?php echo e($a->nama); ?></td>
                        <td class="align-middle text-center text-sm"><?php echo e($a->telp); ?></td}>
                        <td class="align-middle text-center text-sm"><?php echo e($a->email); ?></td>
                        <td class="align-middle text-center text-sm"><?php echo e($a->username); ?></td}>
                     
                        <td>
                        <!-- <a class="btn btn-link text-dark px-3 mb-0" href="/perjalanan/edit/<?php echo e($a->id); ?>"><i class="fas fa-pencil-alt text-dark me-2" aria-hidden="true"></i>Edit</a> -->
                        <a class="btn btn-link text-dark px-3 mb-0" href= "/userr/destroy/<?php echo e($a->id); ?>"><i class="fa fa-trash" aria-hidden="true"> Hapus </i></a></td>  
                        </td}>
                      </tr>
                  </tbody>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
              </div>
            </div>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app_perjalanan\resources\views/userr/index.blade.php ENDPATH**/ ?>