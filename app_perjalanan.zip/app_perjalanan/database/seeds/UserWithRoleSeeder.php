<?php

use Illuminate\Database\Seeder;

class UserWithRoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            'email' => 'nazwaisfalana24@gmail.com',
            'username' => 'nzw.erlna',
            'password' => bcrypt('123'),
            'role' => 'admin'
        ]);

        DB::table('users')->insert([
            'email' => 'thv@gmail.com',
            'username' => 'nnscenery95',
            'password' => bcrypt('123'),
            'role' => 'user'
        ]);


    }
}
