<?php

use Illuminate\Database\Seeder;

 
use Faker\Factory as Faker;
 

class KotaSeeder extends Seeder
{

      public function run()
    {
        $faker = Faker::create('id_ID');
 
    	for($i = 1; $i <= 44; $i++){
 
    		DB::table('kotas')->insert([
    			'nama_kota' => $faker->city,
    		
    		]);
 
    	}
    }
}
