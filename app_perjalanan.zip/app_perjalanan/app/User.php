<?php

namespace App;
use App\Kota;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;
    
    protected $table = 'user';
    protected $primaryKey = 'id';
    protected $fillable = [
        'id',
        'nik',
        'nama',
        'email',
        'telp',
        'username', 
        'password',
        'foto',
        'alamat',
    ];

    public function getImage()
        {
            if (!$this->foto){
                return asset('fotos/tester.jpg');
            }
            return asset('fotos/' .$this->foto);
        }
    

        
    public function kota()
    {
        return $this->belongsTo(Kota::class, 'id_kota');
    }

    protected $hidden = [
        'password', 'remember_token',
    ];

  
    protected $casts = [
        'email_verified_at' => 
        'datetime',
    ];
}
