<?php



Auth::routes();
Route::get('/home', 'HomeController@index')->name('home');


// perjalanan
Route::get('/perjalanan','PerjalananController@index')->middleware('auth','CheckRole:user,admin');
Route::get('/perjalanan/create', 'PerjalananController@create')->middleware('auth','CheckRole:user,admin');
Route::post('/perjalanan/store','PerjalananController@store')->middleware('auth','CheckRole:user,admin');
Route::get('/perjalanan/edit/{id}', 'PerjalananController@edit')->middleware('auth','CheckRole:user,admin');
Route::put('/perjalanan/update/{id}', 'PerjalananController@update')->middleware('auth','CheckRole:user,admin');
Route::get('/perjalanan/destroy/{id}', 'PerjalananController@destroy');
Route::get('/perjalanan/show/{id}', 'PerjalananController@show');


// user
Route::get('/user','userController@index')->middleware('auth','CheckRole:user,admin');
Route::get('/user/create','userController@create')->middleware('auth','CheckRole:user');
Route::post('/user/store','userController@store')->middleware('auth','CheckRole:user');
Route::get('/user/edit/{id}','userController@edit')->middleware('auth','CheckRole:user');
Route::post('/user/update/{id}','userController@update');
Route::get('/user/destroy/{id}', 'userController@destroy');


// kota
Route::get('/kota','KotaController@index');
Route::get('/kota/create','KotaController@create');
Route::post('/kota/store', 'KotaController@store');
Route::get('/kota/destroy/{id}', 'KotaController@destroy');


// userr
Route::get('/userr','UserrController@index')->middleware('auth','CheckRole:admin');
Route::get('/userr/destroy/{id}', 'UserrController@destroy')->middleware('auth','CheckRole:admin');
Route::get('/userr/cetak_pdf', 'UserrController@cetak_pdf');

// gambar
Route::post('/user', 'userController@upload')->name('user.update');


//
Route::get('/profile', 'HomeController@profile');
Route::get('/', function () {
    return view('welcome');
});

;







// home
// Route::get('/welcome','welcomeController@index');

// login
//  Route::get('/login','loginController@login')->name('login');
//  Route::post('/postlogin','loginController@postlogin')->name('postlogin');

// register