@extends('layout.app')
@section('content')
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
          <div class="card mb-4">
            <div class="card-header pb-0">
              <h6>Peduli Diri</h6>
              <a href="/userr/cetak_pdf" target="_blank">
                <button type="button" class="btn btn-success">
                Cetak
                </button>
              </a>
            </div>
            <div class="card-body px-0 pt-0 pb-2">
              <div class="table-responsive p-0">
                <table class="table align-items-center mb-0">
                  <thead>
                    <tr>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">No.</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">NIK</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Nama</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">No Telp</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Email</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Username</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Aksi</th>
                      <th class="text-center text-secondary opacity-7"></th>
                    </tr>
                  </thead>
                  @foreach ($userr as $i => $a) 
                  <tbody>
                    <tr>
                        <td class="align-middle text-center text-sm">{{$i+1}}</td>
                        <td class="align-middle text-center text-sm">{{$a->nik}}</td>
                        <td class="align-middle text-center text-sm">{{$a->nama}}</td>
                        <td class="align-middle text-center text-sm">{{$a->telp}}</td}>
                        <td class="align-middle text-center text-sm">{{$a->email}}</td>
                        <td class="align-middle text-center text-sm">{{$a->username}}</td}>
                     
                        <td>
                        <!-- <a class="btn btn-link text-dark px-3 mb-0" href="/perjalanan/edit/{{$a->id}}"><i class="fas fa-pencil-alt text-dark me-2" aria-hidden="true"></i>Edit</a> -->
                        <a class="btn btn-link text-dark px-3 mb-0" href= "/userr/destroy/{{$a->id}}"><i class="fa fa-trash" aria-hidden="true"> Hapus </i></a></td>  
                        </td}>
                      </tr>
                  </tbody>
                  @endforeach
                </table>
              </div>
            </div>
          </div>
        </div>
    </div>
</div>
@endsection